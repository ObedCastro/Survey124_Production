<?php

session_destroy();

echo '<script>
    window.location.href = "http://localhost/Survey124/inicio";
</script>';