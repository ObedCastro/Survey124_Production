<div class="col-md-5">
  <div class="card z-index-2">
    <div class="card-header pb-0">
      <h6>Asignaciones</h6>
      <p class="text-sm">
        <span class="text-secondary">Muestra el comportamiento de las asignaciones de dispositivos de los ultimos meses</span>
      </p>
    </div>
    <div class="card-body p-3">
      <div class="chart">
        <canvas id="chart-line" class="chart-canvas" height="300"></canvas>
      </div>
    </div>
  </div>
</div>
