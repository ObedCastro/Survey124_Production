<div class="row">
        <div class="col-xl-3 col-sm-6 mb-xl-0 mb-4">
          <div class="card">
            <div class="card-body p-3">
              <div class="row">
                <div class="col-8">
                  <div class="numbers">
                    <p class="text-sm mb-0 text-capitalize font-weight-bold">Telefonos asignados</p>
                    <h5 class="font-weight-bolder mb-0">
                      <?php
                        $dispositivosAsignados = ControladorInicio::ctrMostrarDispositivosAsignados();
                        echo $dispositivosAsignados[0]['telefonosAsignados'];
                      ?>
                      <span class="text-success text-sm font-weight-bolder"> de <?php echo $dispositivosAsignados[0]['totalTelefonos']; ?></span>
                    </h5>
                  </div>
                </div>
                <div class="col-4 text-end">
                  <div class="icon icon-shape bg-gradient-primary shadow text-center border-radius-md">
                  <i class="ni ni-mobile-button text-lg opacity-10" aria-hidden="true"></i>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-xl-3 col-sm-6 mb-xl-0 mb-4">
          <div class="card">
            <div class="card-body p-3">
              <div class="row">
                <div class="col-8">
                  <div class="numbers">
                    <p class="text-sm mb-0 text-capitalize font-weight-bold">Tablets asignadas</p>
                    <h5 class="font-weight-bolder mb-0">
                      <?php echo $dispositivosAsignados[1]["tabletsAsignadas"]; ?>
                      <span class="text-success text-sm font-weight-bolder">de <?php echo $dispositivosAsignados[1]["totalTablets"]; ?></span>
                    </h5>
                  </div>
                </div>
                <div class="col-4 text-end">
                  <div class="icon icon-shape bg-gradient-primary shadow text-center border-radius-md">
                    <i class="ni ni-tablet-button opacity-10" aria-hidden="true"></i>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-xl-3 col-sm-6 mb-xl-0 mb-4">
          <div class="card">
            <div class="card-body p-3">
              <div class="row">
                <div class="col-8">
                  <div class="numbers">
                    <p class="text-sm mb-0 text-capitalize font-weight-bold">Laptops asignadas</p>
                    <h5 class="font-weight-bolder mb-0">
                      <?php echo $dispositivosAsignados[2]["laptopsAsignadas"]; ?>
                      <span class="text-success text-sm font-weight-bolder">de <?php echo $dispositivosAsignados[2]["totalLaptops"]; ?></span>
                    </h5>
                  </div>
                </div>
                <div class="col-4 text-end">
                  <div class="icon icon-shape bg-gradient-primary shadow text-center border-radius-md">
                    <i class="ni ni-laptop text-lg opacity-10" aria-hidden="true"></i>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-xl-3 col-sm-6">
          <div class="card bg-gradient-primary text-white">
            <div class="card-body p-3">
              <div class="row">
                <div class="col-8">
                  <div class="numbers">
                    <p class="text-sm mb-0 text-capitalize font-weight-bold">TOTAL INVENTARIO</p>
                    <h5 class="font-weight-bolder text-white mb-0">
                    <?php echo $dispositivosAsignados[3]["totalInventario"]; ?> <span class="text-xs">Dispositivos</span>
                    </h5>
                  </div>
                </div>
                <div class="col-4 text-end">
                  <div class="icon icon-shape bg-gradient-primary shadow text-center border-radius-md">
                    <i class="ni ni-books text-lg opacity-10" aria-hidden="true"></i>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
