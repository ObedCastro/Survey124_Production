<?php

class Rutas{

    static public function mdlRuta(){
        return "http://localhost/Survey124/";
    }

}